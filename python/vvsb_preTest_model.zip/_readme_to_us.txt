원본 성장 데이터
= prev_growthdata.xlsx

원본 환경데이터
= environments~~.csv

data_graphing = 원본 데이터 추세 분석용
data_pre_processing_growth => 성장데이터 농장별로 분류
ev